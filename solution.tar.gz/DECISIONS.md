# Design Decisions for Line Deduplication Utility

## 1. Data Structure for Tracking Seen Lines
**Ambiguity:** How to efficiently track which lines have been seen while preserving order?

**Chosen Behavior:** Used `LinkedHashSet<String>` for tracking seen lines and `List<String>` for preserving order of unique lines.

**Rationale:** `LinkedHashSet` provides O(1) average-case lookup time and maintains insertion order as a bonus, but we use a separate `List` to explicitly track the output order for clarity. This two-structure approach is clear and efficient even though `LinkedHashSet` alone could work.

## 2. Line Ending Handling
**Ambiguity:** How to handle input with mixed LF and CRLF line endings?

**Chosen Behavior:** Used `BufferedReader.readLine()` which automatically strips both LF and CRLF line terminators from input lines. Output is always written with LF using `PrintWriter.println()`.

**Rationale:** `BufferedReader.readLine()` is the standard, idiomatic Java approach for reading lines with automatic handling of platform-specific and mixed line endings. `PrintWriter.println()` consistently outputs LF on all platforms, meeting the requirement that "output always uses LF".

## 3. Trailing Newline in Output
**Ambiguity:** Should output end with a newline even if input doesn't have a trailing newline?

**Chosen Behavior:** Output always ends with a newline via `PrintWriter.println()`, even if the last line in the input doesn't have a trailing newline.

**Rationale:** The specification states "a trailing newline is emitted after the last line". This is standard POSIX convention and what most Unix tools do.

## 4. Empty Input Handling
**Ambiguity:** What should output be for empty input?

**Chosen Behavior:** Empty input produces empty output (zero bytes).

**Rationale:** The specification explicitly states "empty input produces empty output". When `BufferedReader.readLine()` returns null immediately (no lines read), the loop doesn't execute, and `PrintWriter` writes nothing when given an empty list.

## 5. Empty Line Deduplication
**Ambiguity:** Should empty lines be deduplicated like any other line?

**Chosen Behavior:** Empty lines are treated exactly like any other line - the first occurrence is kept, subsequent ones are dropped.

**Rationale:** The specification states "Empty lines are lines too and deduplicate like any other", making this unambiguous.

## 6. Comparison Method
**Ambiguity:** What constitutes an exact line comparison?

**Chosen Behavior:** Used `String.equals()` for comparison, which is byte-wise on the decoded UTF-8 string and case-sensitive with no trimming.

**Rationale:** `String.equals()` provides exact string comparison. Since input is decoded from UTF-8 bytes via `InputStreamReader(StandardCharsets.UTF_8)`, comparison is byte-wise on the decoded string. No trimming is applied, preserving whitespace as specified.

## 7. Exit Code Behavior
**Ambiguity:** When should exit code be 0 vs 1?

**Chosen Behavior:** Exit code is always 0 on successful operation. I/O errors (caught as `IOException`) are printed to stderr and exit with code 1. No other exceptions are expected.

**Rationale:** The specification states "Exit code 0 always (I/O errors to stderr, exit 1)". The main method catches `IOException` and exits with code 1 per specification. The library method `deduplicate()` throws `IOException` for the caller to handle.

## 8. Library vs CLI Design
**Ambiguity:** Should the deduplication logic be separable from the CLI?

**Chosen Behavior:** Created `deduplicate(InputStream, OutputStream)` as a public static method that can be called from tests and other code, with `main()` using it for the CLI entry point.

**Rationale:** This separation allows thorough testing without spawning subprocesses and makes the logic reusable. The main class still meets the specification of being `bench.task08.Dedup` with a `main` method.

## 9. Charset Encoding
**Ambiguity:** What charset should be used for I/O?

**Chosen Behavior:** All I/O uses UTF-8 encoding explicitly via `StandardCharsets.UTF_8`.

**Rationale:** The specification requires "UTF-8 text lines". Using explicit charset ensures consistent behavior across platforms.

## 10. Large File Handling
**Ambiguity:** How should the utility perform with very large input files?

**Chosen Behavior:** Lines are loaded into memory in a `Set` and `List`. No intermediate storage or streaming approach is used beyond line-level buffering.

**Rationale:** For practical deduplication, all unique lines must eventually be retained in memory. Memory-efficient approaches would require multiple passes or external sorting, which adds complexity. The simple approach of in-memory storage is sufficient for typical use cases and the test suite uses reasonable input sizes.
