package bench.task08;

import org.junit.jupiter.api.Test;

import java.io.*;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class DedupTest {

    private String runDedup(String input) throws IOException {
        ByteArrayInputStream bais = new ByteArrayInputStream(
                input.getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        Dedup.deduplicate(bais, baos);

        return baos.toString(StandardCharsets.UTF_8);
    }

    @Test
    void testBasicDeduplication() throws IOException {
        String input = "b\na\nb\nc\na\n";
        String expected = "b\na\nc\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testEmptyInput() throws IOException {
        String input = "";
        String expected = "";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testSingleLine() throws IOException {
        String input = "hello\n";
        String expected = "hello\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testDuplicates() throws IOException {
        String input = "a\na\na\n";
        String expected = "a\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testEmptyLines() throws IOException {
        String input = "a\n\nb\n\n";
        String expected = "a\n\nb\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testEmptyLineDeduplication() throws IOException {
        String input = "\na\n\nb\n\n";
        String expected = "\na\nb\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testCaseSensitivity() throws IOException {
        String input = "A\na\nA\n";
        String expected = "A\na\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testWhitespacePreserved() throws IOException {
        String input = "a\na \n a\na\n";
        String expected = "a\na \n a\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testNoTrailingNewlineInInput() throws IOException {
        String input = "a\nb\nc";
        String expected = "a\nb\nc\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testMultipleDuplicatesSpread() throws IOException {
        String input = "a\nb\na\nc\nb\na\n";
        String expected = "a\nb\nc\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testSpecialCharacters() throws IOException {
        String input = "café\ncafé\nnaïve\n";
        String expected = "café\nnaïve\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testOrderPreservation() throws IOException {
        String input = "zebra\napple\nbanana\nzebra\n";
        String expected = "zebra\napple\nbanana\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testAllUnique() throws IOException {
        String input = "a\nb\nc\nd\ne\n";
        String expected = "a\nb\nc\nd\ne\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testAllDuplicates() throws IOException {
        String input = "same\nsame\nsame\n";
        String expected = "same\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testLongLines() throws IOException {
        String longLine = "a".repeat(1000);
        String input = longLine + "\nshort\n" + longLine + "\n";
        String expected = longLine + "\nshort\n";
        assertEquals(expected, runDedup(input));
    }

    @Test
    void testManyLines() throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10000; i++) {
            sb.append(i % 100).append("\n");
        }
        String input = sb.toString();

        ByteArrayInputStream bais = new ByteArrayInputStream(
                input.getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        Dedup.deduplicate(bais, baos);

        String output = baos.toString(StandardCharsets.UTF_8);
        String[] lines = output.split("\n", -1);

        assertEquals(101, lines.length);
        for (int i = 0; i < 100; i++) {
            assertEquals(String.valueOf(i), lines[i]);
        }
        assertEquals("", lines[100]);
    }

    @Test
    void testTabs() throws IOException {
        String input = "a\tb\nc\n" + "a\tb\n";
        String expected = "a\tb\nc\n";
        assertEquals(expected, runDedup(input));
    }
}
