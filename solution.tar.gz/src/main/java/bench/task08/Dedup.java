package bench.task08;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Dedup {
    public static void main(String[] args) {
        try {
            deduplicate(System.in, System.out);
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void deduplicate(InputStream input, OutputStream output) throws IOException {
        Set<String> seen = new LinkedHashSet<>();
        List<String> uniqueLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!seen.contains(line)) {
                    seen.add(line);
                    uniqueLines.add(line);
                }
            }
        }

        try (PrintWriter writer = new PrintWriter(
                new OutputStreamWriter(output, StandardCharsets.UTF_8), true)) {
            for (String line : uniqueLines) {
                writer.println(line);
            }
        }
    }
}
